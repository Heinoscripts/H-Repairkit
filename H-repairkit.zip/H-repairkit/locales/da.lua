Locales = Locales or {}

Locales['da'] = {
    no_vehicle = 'Ingen bil i nærheden!',
    inside_vehicle = 'Du skal ud af køretøjet først!',
    repairing = 'Reparerer køretøj...',
    done = 'Køretøjet er repareret!',
    cancelled = 'Reparation afbrudt.',
    no_item = 'Du har ikke et reparationskit!',
}
