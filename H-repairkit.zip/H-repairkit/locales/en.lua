Locales = Locales or {}

Locales['en'] = {
    no_vehicle = 'No vehicle nearby!',
    inside_vehicle = 'Exit the vehicle first!',
    repairing = 'Repairing vehicle...',
    done = 'Vehicle repaired!',
    cancelled = 'Repair cancelled.',
    no_item = 'You don\'t have a repair kit!',
}
