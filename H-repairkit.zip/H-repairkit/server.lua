local Framework = Config.Framework
local ESX = nil
local vRP = nil
local Locales = {}

AddEventHandler('onResourceStart', function(resourceName)
    if resourceName ~= GetCurrentResourceName() then return end
    local localeFile = LoadResourceFile(GetCurrentResourceName(), 'locales/' .. Config.Locale .. '.lua')
    if localeFile then
        local func, err = load(localeFile)
        if func then
            local env = {}
            setmetatable(env, {__index = _G})
            setfenv(func, env) -- For Lua 5.1 (FiveM default), should work
            local success, err2 = pcall(func)
            if success and env.Locales and env.Locales[Config.Locale] then
                Locales = env.Locales[Config.Locale]
            else
                print("[H-repairkit] Failed to load locale table: "..tostring(err2))
            end
        else
            print("[H-repairkit] Failed to load locale file: "..tostring(err))
        end
    else
        print("[H-repairkit] Locale file not found!")
    end
end)

local function Lang(key)
    return Locales[key] or key
end

Citizen.CreateThread(function()
    if Framework == 'auto' then
        if GetResourceState('es_extended') == 'started' then
            Framework = 'esx'
            ESX = exports['es_extended']:getSharedObject()
        elseif GetResourceState('vrp') == 'started' then
            Framework = 'vrp'
            Proxy = Proxy or Proxy
            Tunnel = Tunnel or Tunnel
            vRP = Proxy.getInterface('VRP')
        else
            print("[H-repairkit] No framework detected")
        end
    elseif Framework == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
    elseif Framework == 'vrp' then
        Proxy = Proxy or Proxy
        Tunnel = Tunnel or Tunnel
        vRP = Proxy.getInterface('vRP')
    end
end)

RegisterNetEvent('H-repairkit:useItem', function()
    local src = source

    if Framework == 'esx' then
        local xPlayer = ESX.GetPlayerFromId(src)
        if xPlayer and xPlayer.getInventoryItem(Config.ItemName).count > 0 then
            xPlayer.removeInventoryItem(Config.ItemName, 1)
            TriggerClientEvent('H-repairkit:useKit', src)
        else
            TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = Lang('no_item')})
        end
    elseif Framework == 'vrp' then
        local user_id = VRP.getUserId({src})
        if user_id and VRP.tryGetInventoryItem({user_id, Config.ItemName, 1, true}) then
            TriggerClientEvent('H-repairkit:useKit', src)
        else
            TriggerClientEvent('ox_lib:notify', src, {type = 'error', description = Lang('no_item')})
        end
    else
        print("[H-repairkit] No compatible framework detected for player ID: " .. src)
    end
end)
