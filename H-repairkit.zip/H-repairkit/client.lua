---@diagnostic disable: undefined-field, need-check-nil
local Framework = nil -- 'esx' or 'vrp' or 'auto'
local ESX, vRP, vRPclient = nil, nil, nil
local Translations = Locales[Config.Locale]

local repairing = false
local cancel = false

Citizen.CreateThread(function()
    if Config.Framework == 'auto' then
        if exports['es_extended'] then
            Framework = 'esx'
            ESX = exports['es_extended']:getSharedObject()
            if Config.Debug then print('[H-repairkit] Detected ESX') end
        elseif Tunnel and Proxy then
            Framework = 'vrp'
            Proxy = Proxy or Proxy
            Tunnel = Tunnel or Tunnel
            vRP = Proxy.getInterface('vRP')
            vRPclient = Tunnel.getInterface('vRP','H-repairkit')
            if Config.Debug then print('[H-repairkit] Detected vRP') end
        else
            if Config.Debug then print('[H-repairkit] No framework detected!') end
        end
    else
        Framework = Config.Framework
        if Framework == 'esx' then
            ESX = exports['es_extended']:getSharedObject()
        elseif Framework == 'vrp' then
            Proxy = Proxy or Proxy
            Tunnel = Tunnel or Tunnel
            vRP = Proxy.getInterface('vRP')
            vRPclient = Tunnel.getInterface('vRP','H-repairkit')
        end
    end
end)

local function notify(type, message)
    lib.notify({
        title = 'Repair Kit',
        description = message,
        type = type
    })
end

local function getClosestVehicle(radius)
    local ped = PlayerPedId()
    local pedCoords = GetEntityCoords(ped)
    if Framework == 'esx' then
        return ESX.Game.GetClosestVehicle(pedCoords)
    elseif Framework == 'vrp' then
        local vehicles = GetGamePool('CVehicle')
        local closestVeh = nil
        local closestDist = radius + 1
        for _, veh in pairs(vehicles) do
            local dist = #(GetEntityCoords(veh) - pedCoords)
            if dist < radius and dist < closestDist then
                closestVeh = veh
                closestDist = dist
            end
        end
        return closestVeh
    else
        return ESX and ESX.Game.GetClosestVehicle(pedCoords) or nil
    end
end

local function cancelRepair(ped)
    ClearPedTasks(ped)
    if Config.FreezePlayer then
        FreezeEntityPosition(ped, false)
    end
    repairing = false
    cancel = false
    notify('error', Translations['cancelled'])
end

RegisterNetEvent('H-repairkit:useKit', function()
    if repairing then return end

    local ped = PlayerPedId()

    if IsPedInAnyVehicle(ped, false) then
        notify('error', Translations['inside_vehicle'])
        return
    end

    local vehicle = getClosestVehicle(Config.RepairRadius)

    if not vehicle or vehicle == 0 or not DoesEntityExist(vehicle) then
        notify('error', Translations['no_vehicle'])
        return
    end

    repairing = true
    cancel = false

    if Config.FreezePlayer then
        FreezeEntityPosition(ped, true)
    end

    if Config.UseScenario then
        TaskStartScenarioInPlace(ped, Config.Scenario, 0, true)
    else
        RequestAnimDict(Config.Animation.dict)
        while not HasAnimDictLoaded(Config.Animation.dict) do Wait(0) end
        TaskPlayAnim(ped, Config.Animation.dict, Config.Animation.anim, 8.0, -8.0, -1, 1, 0, false, false, false)
    end

    CreateThread(function()
        while repairing do
            if IsControlJustPressed(0, Config.CancelKey) then
                cancel = true
                break
            end
            Wait(0)
        end
    end)

    if Config.UseProgressBar then
        local finished = lib.progressBar({
            duration = Config.RepairDuration,
            label = Translations['repairing'],
            useWhileDead = false,
            canCancel = false,
            disable = { move = true, combat = true, car = true }
        })

        if cancel then
            cancelRepair(ped)
            return
        end

        if finished then
            ClearPedTasks(ped)
            if Config.FreezePlayer then
                FreezeEntityPosition(ped, false)
            end
            repairing = false

            SetVehicleFixed(vehicle)
            SetVehicleUndriveable(vehicle, false)

            notify('success', Translations['done'])
        else
            cancelRepair(ped)
        end
    else
        local timer = 0
        while timer < Config.RepairDuration do
            if cancel then
                cancelRepair(ped)
                return
            end
            Wait(100)
            timer = timer + 100
        end
        ClearPedTasks(ped)
        if Config.FreezePlayer then
            FreezeEntityPosition(ped, false)
        end
        repairing = false

        SetVehicleFixed(vehicle)
        SetVehicleUndriveable(vehicle, false)

        notify('success', Translations['done'])
    end
end)
RegisterNetEvent('H-repairkit:cancelRepair', function()
    if repairing then
        cancel = true
    end
end)
