fx_version 'cerulean'
game 'gta5'

description 'H-repairkit - A simple repair kit script for ESX'

author 'H-dev'
version '1.1.0'

shared_script 'config.lua'

client_scripts {
    '@es_extended/imports.lua',
    '@ox_lib/init.lua',
    'locales/*.lua',
    'client.lua'
}

server_scripts {
    '@vrp/lib/utils.lua', -- only if you use vRP
    'server.lua'
}
