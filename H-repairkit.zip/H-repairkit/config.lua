Config = {}

-- 'esx', 'vrp' or 'auto' to detect automatically
Config.Framework = 'auto'

Config.Locale = 'en' -- 'en' or 'da'

Config.ItemName = 'repairkit' -- ItemName

Config.RepairDuration = 10000 -- In ms

Config.RepairRadius = 5.0 -- max distance to vehicle to repair

Config.CancelKey = 73 -- X

Config.FreezePlayer = true

Config.UseProgressBar = true -- show progress bar

Config.UseScenario = false -- true = scenario, false = animation

Config.Scenario = 'WORLD_HUMAN_WELDING'

Config.Animation = {
    dict = 'mini@repair',
    anim = 'fixing_a_ped'
}

Config.Debug = false -- enable debug prints for further development
Config.DebugPrint = function(msg)
    if Config.Debug then
        print('H-repairkit: ' .. msg)
    end
end